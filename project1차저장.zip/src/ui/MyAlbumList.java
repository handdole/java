package ui;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Panel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MyAlbumList {
	public void MyAlbumList() {
		JFrame f4 = new JFrame();
		f4.getContentPane().setBackground(Color.GREEN);
		f4.setSize(1600, 860);
		f4.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("나만의 앨범 목록");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 50));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(88, 24, 1402, 62);
		f4.getContentPane().add(lblNewLabel);
		
		Panel panel = new Panel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(88, 137, 1402, 588);
		f4.getContentPane().add(panel);
		panel.setLayout(null);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.GREEN);
		panel_1.setBounds(10, 10, 1382, 59);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("게시물 번호");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(12, 10, 75, 39);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("이미지 커버");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(118, 10, 75, 39);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("나만의 앨범 제목");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1.setBounds(220, 10, 695, 39);
		panel_1.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("수록곡 수");
		lblNewLabel_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1.setBounds(940, 10, 83, 39);
		panel_1.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("태그");
		lblNewLabel_1_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1_1.setBounds(1035, 10, 140, 39);
		panel_1.add(lblNewLabel_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_2 = new JLabel("닉네임");
		lblNewLabel_1_1_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1_2.setBounds(1187, 10, 83, 39);
		panel_1.add(lblNewLabel_1_1_1_1_2);
		
		JLabel lblNewLabel_1_1_1_1_2_1 = new JLabel("좋아요 수");
		lblNewLabel_1_1_1_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1_1_1_2_1.setBounds(1299, 10, 54, 39);
		panel_1.add(lblNewLabel_1_1_1_1_2_1);
		
		JButton btnNewButton_2 = new JButton("New button");
		btnNewButton_2.setBounds(263, 95, 663, 23);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBounds(35, 99, 57, 23);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("앨범커버");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(143, 81, 50, 50);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(951, 95, 82, 23);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("New label");
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setBounds(1055, 95, 126, 23);
		panel.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("New label");
		lblNewLabel_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2.setBounds(1192, 95, 100, 23);
		panel.add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_4_3 = new JLabel("New label");
		lblNewLabel_4_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3.setBounds(1304, 95, 86, 23);
		panel.add(lblNewLabel_4_3);
		
		JLabel lblNewLabel_2_1 = new JLabel("New label");
		lblNewLabel_2_1.setBounds(35, 173, 57, 23);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("앨범커버");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setBounds(143, 155, 50, 50);
		panel.add(lblNewLabel_3_1);
		
		JButton btnNewButton_2_1 = new JButton("New button");
		btnNewButton_2_1.setBounds(263, 169, 663, 23);
		panel.add(btnNewButton_2_1);
		
		JLabel lblNewLabel_4_4 = new JLabel("New label");
		lblNewLabel_4_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_4.setBounds(951, 169, 82, 23);
		panel.add(lblNewLabel_4_4);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("New label");
		lblNewLabel_4_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_1.setBounds(1055, 169, 126, 23);
		panel.add(lblNewLabel_4_1_1);
		
		JLabel lblNewLabel_4_2_1 = new JLabel("New label");
		lblNewLabel_4_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2_1.setBounds(1192, 169, 100, 23);
		panel.add(lblNewLabel_4_2_1);
		
		JLabel lblNewLabel_4_3_1 = new JLabel("New label");
		lblNewLabel_4_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3_1.setBounds(1304, 169, 86, 23);
		panel.add(lblNewLabel_4_3_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("New label");
		lblNewLabel_2_2.setBounds(35, 247, 57, 23);
		panel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_3_2 = new JLabel("앨범커버");
		lblNewLabel_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_2.setBounds(143, 229, 50, 50);
		panel.add(lblNewLabel_3_2);
		
		JButton btnNewButton_2_2 = new JButton("New button");
		btnNewButton_2_2.setBounds(263, 243, 663, 23);
		panel.add(btnNewButton_2_2);
		
		JLabel lblNewLabel_4_5 = new JLabel("New label");
		lblNewLabel_4_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_5.setBounds(951, 243, 82, 23);
		panel.add(lblNewLabel_4_5);
		
		JLabel lblNewLabel_4_1_2 = new JLabel("New label");
		lblNewLabel_4_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_2.setBounds(1055, 243, 126, 23);
		panel.add(lblNewLabel_4_1_2);
		
		JLabel lblNewLabel_4_2_2 = new JLabel("New label");
		lblNewLabel_4_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2_2.setBounds(1192, 243, 100, 23);
		panel.add(lblNewLabel_4_2_2);
		
		JLabel lblNewLabel_4_3_2 = new JLabel("New label");
		lblNewLabel_4_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3_2.setBounds(1304, 243, 86, 23);
		panel.add(lblNewLabel_4_3_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("New label");
		lblNewLabel_2_3.setBounds(35, 322, 57, 23);
		panel.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_3_3 = new JLabel("앨범커버");
		lblNewLabel_3_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_3.setBounds(143, 304, 50, 50);
		panel.add(lblNewLabel_3_3);
		
		JButton btnNewButton_2_3 = new JButton("New button");
		btnNewButton_2_3.setBounds(263, 318, 663, 23);
		panel.add(btnNewButton_2_3);
		
		JLabel lblNewLabel_4_6 = new JLabel("New label");
		lblNewLabel_4_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_6.setBounds(951, 318, 82, 23);
		panel.add(lblNewLabel_4_6);
		
		JLabel lblNewLabel_4_1_3 = new JLabel("New label");
		lblNewLabel_4_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_3.setBounds(1055, 318, 126, 23);
		panel.add(lblNewLabel_4_1_3);
		
		JLabel lblNewLabel_4_2_3 = new JLabel("New label");
		lblNewLabel_4_2_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2_3.setBounds(1192, 318, 100, 23);
		panel.add(lblNewLabel_4_2_3);
		
		JLabel lblNewLabel_4_3_3 = new JLabel("New label");
		lblNewLabel_4_3_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3_3.setBounds(1304, 318, 86, 23);
		panel.add(lblNewLabel_4_3_3);
		
		JLabel lblNewLabel_2_4 = new JLabel("New label");
		lblNewLabel_2_4.setBounds(35, 395, 57, 23);
		panel.add(lblNewLabel_2_4);
		
		JLabel lblNewLabel_3_4 = new JLabel("앨범커버");
		lblNewLabel_3_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_4.setBounds(143, 377, 50, 50);
		panel.add(lblNewLabel_3_4);
		
		JButton btnNewButton_2_4 = new JButton("New button");
		btnNewButton_2_4.setBounds(263, 391, 663, 23);
		panel.add(btnNewButton_2_4);
		
		JLabel lblNewLabel_4_7 = new JLabel("New label");
		lblNewLabel_4_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_7.setBounds(951, 391, 82, 23);
		panel.add(lblNewLabel_4_7);
		
		JLabel lblNewLabel_4_1_4 = new JLabel("New label");
		lblNewLabel_4_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_4.setBounds(1055, 391, 126, 23);
		panel.add(lblNewLabel_4_1_4);
		
		JLabel lblNewLabel_4_2_4 = new JLabel("New label");
		lblNewLabel_4_2_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2_4.setBounds(1192, 391, 100, 23);
		panel.add(lblNewLabel_4_2_4);
		
		JLabel lblNewLabel_4_3_4 = new JLabel("New label");
		lblNewLabel_4_3_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3_4.setBounds(1304, 391, 86, 23);
		panel.add(lblNewLabel_4_3_4);
		
		JLabel lblNewLabel_2_5 = new JLabel("New label");
		lblNewLabel_2_5.setBounds(35, 465, 57, 23);
		panel.add(lblNewLabel_2_5);
		
		JLabel lblNewLabel_3_5 = new JLabel("앨범커버");
		lblNewLabel_3_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_5.setBounds(143, 447, 50, 50);
		panel.add(lblNewLabel_3_5);
		
		JButton btnNewButton_2_5 = new JButton("New button");
		btnNewButton_2_5.setBounds(263, 461, 663, 23);
		panel.add(btnNewButton_2_5);
		
		JLabel lblNewLabel_4_8 = new JLabel("New label");
		lblNewLabel_4_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_8.setBounds(951, 461, 82, 23);
		panel.add(lblNewLabel_4_8);
		
		JLabel lblNewLabel_4_1_5 = new JLabel("New label");
		lblNewLabel_4_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_5.setBounds(1055, 461, 126, 23);
		panel.add(lblNewLabel_4_1_5);
		
		JLabel lblNewLabel_4_2_5 = new JLabel("New label");
		lblNewLabel_4_2_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2_5.setBounds(1192, 461, 100, 23);
		panel.add(lblNewLabel_4_2_5);
		
		JLabel lblNewLabel_4_3_5 = new JLabel("New label");
		lblNewLabel_4_3_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3_5.setBounds(1304, 461, 86, 23);
		panel.add(lblNewLabel_4_3_5);
		
		JLabel lblNewLabel_2_6 = new JLabel("New label");
		lblNewLabel_2_6.setBounds(35, 532, 57, 23);
		panel.add(lblNewLabel_2_6);
		
		JLabel lblNewLabel_3_6 = new JLabel("앨범커버");
		lblNewLabel_3_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_6.setBounds(143, 514, 50, 50);
		panel.add(lblNewLabel_3_6);
		
		JButton btnNewButton_2_6 = new JButton("New button");
		btnNewButton_2_6.setBounds(263, 528, 663, 23);
		panel.add(btnNewButton_2_6);
		
		JLabel lblNewLabel_4_9 = new JLabel("New label");
		lblNewLabel_4_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_9.setBounds(951, 528, 82, 23);
		panel.add(lblNewLabel_4_9);
		
		JLabel lblNewLabel_4_1_6 = new JLabel("New label");
		lblNewLabel_4_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1_6.setBounds(1055, 528, 126, 23);
		panel.add(lblNewLabel_4_1_6);
		
		JLabel lblNewLabel_4_2_6 = new JLabel("New label");
		lblNewLabel_4_2_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_2_6.setBounds(1192, 528, 100, 23);
		panel.add(lblNewLabel_4_2_6);
		
		JLabel lblNewLabel_4_3_6 = new JLabel("New label");
		lblNewLabel_4_3_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_3_6.setBounds(1304, 528, 86, 23);
		panel.add(lblNewLabel_4_3_6);
		
		JButton btnNewButton = new JButton("이전");
		btnNewButton.setBounds(350, 752, 199, 43);
		f4.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("다음");
		btnNewButton_1.setBounds(818, 752, 199, 43);
		f4.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("뒤로가기");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyAlubm myalbum = new MyAlubm();
				myalbum.MyAlbum();
				f4.setVisible(false);
			}
		});
		btnNewButton_3.setBounds(1359, 749, 131, 46);
		f4.getContentPane().add(btnNewButton_3);
		
		
		
		
		f4.setVisible(true);
		
		
	}

}
