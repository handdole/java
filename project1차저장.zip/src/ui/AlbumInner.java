package ui;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Panel;
import javax.swing.JButton;

public class AlbumInner {
	/**
	 * @wbp.parser.entryPoint
	 */
	public void AlbumInner() {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(1600, 860);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("나만의 앨범 정보 ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 50));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(52, 40, 409, 61);
		f.getContentPane().add(lblNewLabel);
		
		Panel panel_1 = new Panel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(146, 220, 356, 531);
		f.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("게시물번호");
		lblNewLabel_1_1.setBounds(27, 10, 74, 30);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_3_5 = new JLabel("TITLE");
		lblNewLabel_3_5.setBounds(27, 368, 102, 23);
		panel_1.add(lblNewLabel_3_5);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("NICKNAME");
		lblNewLabel_3_1_1.setBounds(27, 401, 102, 23);
		panel_1.add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("TAG/TAG/TAG/TAG");
		lblNewLabel_3_2_1.setBounds(27, 449, 245, 23);
		panel_1.add(lblNewLabel_3_2_1);
		
		JLabel lblNewLabel_3_3_1 = new JLabel("수록곡 수");
		lblNewLabel_3_3_1.setBounds(27, 487, 119, 23);
		panel_1.add(lblNewLabel_3_3_1);
		
		JLabel lblNewLabel_3_4_1 = new JLabel("LIKE");
		lblNewLabel_3_4_1.setBounds(242, 491, 102, 23);
		panel_1.add(lblNewLabel_3_4_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("앨범커버");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_1.setBounds(27, 50, 295, 295);
		panel_1.add(lblNewLabel_2_1);
		
		Panel panel = new Panel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(593, 220, 850, 531);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("수록곡");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(12, 10, 826, 31);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel(" 1. 수록곡명 아티스트 앨범이름 좋아요수 .....");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setBounds(12, 51, 826, 39);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_2 = new JLabel(" 2. 수록곡명 아티스트 앨범이름 좋아요수 .....");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2_2.setBounds(12, 100, 826, 39);
		panel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel(" 3. 수록곡명 아티스트 앨범이름 좋아요수 .....");
		lblNewLabel_2_3.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2_3.setBounds(12, 146, 826, 39);
		panel.add(lblNewLabel_2_3);
		
		JLabel lblNewLabel_2_3_1 = new JLabel(" 3. 수록곡명 아티스트 앨범이름 좋아요수 .....");
		lblNewLabel_2_3_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2_3_1.setBounds(12, 195, 826, 39);
		panel.add(lblNewLabel_2_3_1);
		
		JButton btnNewButton = new JButton("이전");
		btnNewButton.setBounds(1180, 768, 263, 43);
		f.getContentPane().add(btnNewButton);
		
		
		
		
		
		f.setVisible(true);
		
		
	}
	
}
