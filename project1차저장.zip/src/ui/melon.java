package ui;

public class melon {

	public static void main(String[] args) {
//		login start = new login();
//		start.loginUI();
		MyAlubm start2 = new MyAlubm();
		start2.MyAlbum();

		
	}

}
