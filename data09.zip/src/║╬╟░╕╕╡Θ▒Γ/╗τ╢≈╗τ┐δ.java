package ��ǰ�����;

public class ������ {

	public static void main(String[] args) {
		person p1 = new person();
		person p2 = new person();
		person p3 = new person();
		p1.eat();
		p2.talk();
		p3.tool();
		p1.name = "ȫ�浿";
		p1.age = 100;
		p1.gender = '��';
		
		System.out.println(p1.name);
		
		
	}

}
