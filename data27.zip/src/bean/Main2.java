package bean;

public class Main2 {
	public static void main(String[] args) {
		ConManager n = ConManager.getInstance();
		System.out.println(n.getElement(0));
	}
}
