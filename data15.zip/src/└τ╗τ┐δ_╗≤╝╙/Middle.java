package 재사용_상속;

public class Middle extends Student{
	public void study() {
		System.out.println("단소 공부하다.");
	}
}
