package 재사용_상속;

public class WonderWoman extends Woman {
	String hero;
	
	public void take() {
		System.out.println("무기 꺼냄");
	}
	
}
