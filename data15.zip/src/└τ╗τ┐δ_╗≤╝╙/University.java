package 재사용_상속;

public class University extends Student{
	public void study() {
		System.out.println("토익 공부하다.");
	}
}
