package 재사용_상속;

public class Student {
		
	public void study() {
		System.out.println("공부하다.");
		
	}
}
