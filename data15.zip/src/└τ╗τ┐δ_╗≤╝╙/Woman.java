package 재사용_상속;

public class Woman extends Person {
	
	int brain;
	
	
	public void soft() {
		System.out.println("할게없다...");
	}
	
	
	
}
