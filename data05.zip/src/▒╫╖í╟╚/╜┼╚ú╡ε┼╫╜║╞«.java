package �׷���;

import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.Font;

public class ��ȣ���׽�Ʈ {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(400, 900);
		f.setTitle("��ȣ��");
		f.getContentPane().setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JButton btnNewButton = new JButton("\uCD08\uB85D\uC2E0\uD638");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel img = new JLabel();
				ImageIcon icon = new ImageIcon("g.png");
				img.setIcon(icon);
				f.getContentPane().add(img);
				f.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("����", Font.PLAIN, 84));
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uB178\uB791\uC2E0\uD638");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel img = new JLabel();
				ImageIcon icon = new ImageIcon("y.png");
				img.setIcon(icon);
				f.getContentPane().add(img);
				f.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("����", Font.PLAIN, 84));
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\uBE68\uAC15\uC2E0\uD638");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel img = new JLabel();
				ImageIcon icon = new ImageIcon("r.png");
				img.setIcon(icon);
				f.getContentPane().add(img);
				f.setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("����", Font.PLAIN, 84));
		f.getContentPane().add(btnNewButton_2);
		
		
		f.setVisible(true);
		
	}
}
