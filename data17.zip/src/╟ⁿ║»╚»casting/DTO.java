package 형변환casting;

public class DTO {
	String id;
	String pw;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	@Override
	public String toString() {
		return "DTO [id=" + id + ", pw=" + pw + "]";
	}
	
	
}
