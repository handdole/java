package 형변환casting;

public class 기본데이터형변환 {
	public static void main(String[] args) {
		
	}
}
