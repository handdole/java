package 스레드;

public class Mainclass {
	public static void main(String[] args) {
		Star name = new Star();
		tel name2 = new tel();
		name.run();
		name2.run();
	}
}
