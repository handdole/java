package 스레드;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JLabel;

public class Mainclass2 extends JFrame {
	JLabel lblcount , lblimg , lbltime; 
	
	public Mainclass2() {
		getContentPane().setBackground(Color.ORANGE);
		getContentPane().setLayout(null);
		
		lblcount = new JLabel("count :");
		lblcount.setBounds(48, 31, 203, 36);
		getContentPane().add(lblcount);
		
		
		lblimg = new JLabel("");
		lblimg.setBounds(118, 120, 535, 198);
		getContentPane().add(lblimg);
		
		
		lbltime = new JLabel("시간");
		lbltime.setBounds(118, 344, 535, 36);
		getContentPane().add(lbltime);
		setTitle("스레드"); 
		setSize(800, 500);
		
		Count c = new Count();
		c.start();
		Time t = new Time();
		t.start();
		Img i = new Img();
		i.start();
		
		setVisible(true);
		
		
		
	}
	
	//내부클래스 (inner class)
	//독립적으로 객체생성 불가.
	//외부클래스의 있는 멤버변수를 공유할 목적으로 사용됨.
	
	public class Count extends Thread {
		public void run() {
			
			for (int i = 100; i >= 0; i--) {
				
				try {   // 외부자원을 사용할 때는 try catch를 사용해야함.   cpu를 건드리는 작업이기 때문에 try catch 필수.
					Thread.sleep(1000);   // 이게 1초 
				} catch (Exception e) {
				}
				lblcount.setText("count: " + i);
				if(i==0) System.exit(0);
			}
		}
	}
	
	public class Time extends Thread {
		public void run() {
			
			for (int i = 0; i < 100; i++) {
				
				try {   // 외부자원을 사용할 때는 try catch를 사용해야함.   cpu를 건드리는 작업이기 때문에 try catch 필수.
					Thread.sleep(1000);   // 이게 1초    // void형 static 메소드 입력값은 int.
				} catch (Exception e) {
				}
//				Date date = new Date();
				Calendar cal = Calendar.getInstance();
				lbltime.setText(cal.getTime()+"");
			}
			
			
		}
	}
	
	public class Img extends Thread {
		public void run() {
			String[] list = {"002.png","003.png","004.png","005.png","006.png"};
			for (int i = 0; i < 100; i++) {
				try {   // 외부자원을 사용할 때는 try catch를 사용해야함.   cpu를 건드리는 작업이기 때문에 try catch 필수.
					Thread.sleep(1000);   // 이게 1초    // void형 static 메소드 입력값은 int.
				} catch (Exception e) {
				}
				ImageIcon icon = new ImageIcon(list[i%5]);
				lblimg.setIcon(icon);
			}
			
			
		}
	}
	
	
	
	
	
	public static void main(String[] args) {
		new Mainclass2();
	}
}
