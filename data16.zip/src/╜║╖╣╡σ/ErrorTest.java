package 스레드;

public class ErrorTest {
	public static void main(String[] args) {
		System.out.println("test");
		int x;
		System.out.println(x);
		
		System.out.println("프로그램 끝!");   // 에러의 정석 컴파일 단계에서 잘못된 케이스
	}
}
