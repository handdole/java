package 스레드;

public class Main {
	public static void main(String[] args) {
		Fortestone one = new Fortestone();
		Fortesttwo two = new Fortesttwo();
		
		one.start(); // cpu에 thread를 등록
		two.start(); // 
		
	}
}
