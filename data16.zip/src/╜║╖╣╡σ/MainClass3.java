package 스레드;

public class MainClass3 {
	public static void main(String[] args) throws Exception {
		ErrorTest3 e4 = new ErrorTest3();
		e4.call();
	}
}
