package 스레드;

import javax.swing.JOptionPane;

//ctrl + f11 : complie(javac Error2.java) ------->Error2.class---->run(java Error2)
//				요기서 발견되는 에러는 문법 에러				
public class ErrorTest2 {
	public static void main(String[] args) {
		int[] num = {1,2,3};
		
		
		//에러가 발생한 경우 , 이 에러가 발생한 메소드 내에서 
		//에러가 발생했을 때 처리할 내용을 바로 넣어서 처리. 이럴 때는 Try Catch
		try {
			num[3] = 4; //runtime error    // 츄라이 해보고 안되면 exception 에 넣어줘 
			
		} catch (ArrayIndexOutOfBoundsException e) {
			JOptionPane.showMessageDialog(null, "에러 발생함 , 확인요청!!");
//			System.out.println("에러발생함");
			e.printStackTrace();
		}
		
		System.out.println(num[0]);  // 이거는 실행단계의 에러 (런타임 에러)
	}
}
