package game;

public class Car1 extends Thread {
	
}
