package game;

import java.awt.Color;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPanel;

public class Cargame extends JFrame{  // jframe 을 상속받아서 사용
	
	public Cargame() {
		setBackground(Color.GREEN);
		getContentPane().setBackground(Color.GREEN);
		setTitle("자동차 경주");    // jframe의 제목 지정
		setSize(800, 600);      // 사이즈 지정
		getContentPane().setLayout(null);		// 레이아웃 지정
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 40));
		lblNewLabel.setBounds(88, 21, 634, 73);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GREEN);
		panel.setBounds(40, 165, 640, 138);
		getContentPane().add(panel);


		
		Car car1 = new Car("car01.png",25,101);   // Car 라는 클래스 만들어서 객체 생성 car는 생성자이고 입력값이 필요한 클레스이다.
		Car car2 = new Car("car02.png",25,249);	  // 이미지 파일이름 , x축 , y축 순으로 넣어야함.
		Car car3 = new Car("car03.png",25,408);
		
		car1.start();    //car1 실행	  // cpu 스케줄링에 등록해주고 나머지는 cpu가 돌리게 실행.
		car2.start();	//car2실행
		car3.start();	//car3실행
		
		setVisible(true);    
	}
	
	public class Car extends Thread{    //car라는 클래스 생성 쓰레드 상속받음
		int x , y ;    // 전역변수로 x,y를 지정 차가 움직이는것을 표현할 때 x축은 바뀌고 y축은 고정이기 때문에 전역변수로 지정해주고 
		JLabel lbl;   // 같은 라벨이 다른 메소드 사용되기 때문에 전역변수로 지정하여 새로운 라벨이 안생기도록 설정. 
		
		//생성자 , constructor 생성.
		public Car( String file , int x , int y ) {
			ImageIcon icon = new ImageIcon(file);
			lbl = new JLabel(icon);     //전역변수 선언하고 한번더 지역변수로 선언하면 새로운 변수인것으로 인식.
			this.x = x;      //x의 값이 전역변수로 가서 초기값이 안되도록 this키워드 사용하여 x 값 유지
			this.y = y;		// y의 값이 전역변수로 가서 초기값이 안되도록 this키워드 사용하여 y 값 유지
			lbl.setBounds(x, y, 145, 90);   // 크기는 일정하기 때문에 크기는 고정 ,x ,y 축은 변하기 때문에 입력값에 들어있는 변수로 지정.
			add(lbl);   // lbl을 frame에 add함.
		}
		
		@Override
		public void run() {    // start를 하면 cpu에 등록되는 메소드
			Random r = new Random();  // 랜덤값을 만들기 위한 객체 생성
			for (int i = 0; i < 200; i++) {    // 200번 실행하기위해 for문 사용
				int move = r.nextInt(50);    //0~49까지의 난수 생성 
				x = x + move;    // 초기 x값 + move 라는 난수를 합하여 x값에 저장. 이값은 위에 this.x 값에 계속 들어가게 됨.
				lbl.setBounds(x, y, 145, 90);  // x값이 계속 바뀌기 때문에 자동차가 움직이는 것으로 보임.
				
				//포커스는 오류에 잡혀있는거임. 근데 오류 날것들을 생각해보니까,강제적으로 잡아줘야할것들이 몇개있어 그게 => 네트워크 , DBMS , CPU관련.
				try {  // 외부 자원(네트워크 , DBMS , 쓰레드할 때 CPU )을 사용할 때는 try catch를 사용해야함. cpu를 건들이는 거기 때문에 필수.
					Thread.sleep(500);
				} catch (Exception e) {
				}
			}
			
			
		}
	}
	
	
	
	
	
	public static void main(String[] args) {
		new Cargame();
	}
}
