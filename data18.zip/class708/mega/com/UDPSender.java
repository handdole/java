package class708.mega.com;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPSender {
	public static void main(String[] args) throws Exception {
		//���ۿ� ������ ������. 
		DatagramSocket socket = new DatagramSocket();
		String data = "I am happy..!!!";
		byte[] buf = data.getBytes();
		InetAddress address = InetAddress.getByName("127.0.0.1");
		
		DatagramPacket packet = new DatagramPacket(buf, buf.length, address, 9999);
		
		socket.send(packet);
		System.out.println("UDP packet ���� �Ϸ�.");
		socket.close();
	}
}
