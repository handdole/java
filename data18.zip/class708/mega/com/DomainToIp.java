package class708.mega.com;

import java.net.InetAddress;

public class DomainToIp {
	public static void main(String[] args) throws Exception{  // ��ĳ���� �� ����.
		String name = "www.kku.ac.kr";
		InetAddress ipInfo = InetAddress.getByName(name);
		System.out.println(ipInfo);
		
	}
}
