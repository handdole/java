package 생성자;

import javax.swing.JOptionPane;

public class news {

	public void news() {
		JOptionPane.showMessageDialog(null, "뉴스: "+test.logid+"님 환영합니다.");
	}

}
