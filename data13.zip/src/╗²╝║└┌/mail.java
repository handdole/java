package 생성자;

import javax.swing.JOptionPane;

public class mail {

	public void mail() {
		JOptionPane.showMessageDialog(null,"메일" +  test.logid+"님 환영합니다.");
	}

}
