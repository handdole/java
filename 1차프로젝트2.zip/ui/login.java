package ui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRootPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;

public class login {
	JFrame f = new JFrame();

	private JTextField tloginID;
	private JTextField tloginPW;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void loginUI() {
		f.setTitle("로그인 화면");
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(1600, 860);
		f.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("MELON");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 50));
		lblNewLabel.setBounds(579, 124, 491, 68);
		f.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("아이디");
		lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 35));
		lblNewLabel_1.setBounds(273, 291, 267, 73);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("비밀번호");
		lblNewLabel_1_1.setFont(new Font("굴림", Font.PLAIN, 35));
		lblNewLabel_1_1.setBounds(273, 477, 267, 73);
		f.getContentPane().add(lblNewLabel_1_1);

		tloginID = new JTextField();
		tloginID.setBounds(629, 291, 627, 79);
		f.getContentPane().add(tloginID);
		tloginID.setColumns(10);

		tloginPW = new JTextField();
		tloginPW.setColumns(10);
		tloginPW.setBounds(629, 477, 627, 79);
		f.getContentPane().add(tloginPW);

		JButton btnNewButton = new JButton("로그인");
		btnNewButton.setFont(new Font("굴림", Font.PLAIN, 35));
		btnNewButton.setBounds(300, 692, 389, 68);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("회원가입");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JoinMembership join = new JoinMembership();
				join.joinmembershipUI();
				f.setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("굴림", Font.PLAIN, 35));
		btnNewButton_1.setBounds(867, 692, 389, 68);
		f.getContentPane().add(btnNewButton_1);

		f.setVisible(true);
		
		JRootPane  rootPane  =  f.getRootPane();
        rootPane.setDefaultButton(btnNewButton);  
		
	}
	
}
