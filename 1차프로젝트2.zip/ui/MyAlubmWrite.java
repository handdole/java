package ui;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Panel;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DB.MyAlbumBbsDAO;
import DB.MyAlbumBbsDTO;
import DB.SongDAO;
import DB.SongDTO;
import DB.file;

import javax.swing.JScrollPane;
import java.awt.Scrollbar;
import java.awt.TextField;

import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.lang.reflect.Parameter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.JCheckBox;

public class MyAlubmWrite {
	
	
	JFrame f3 = new JFrame();
	private static JTextField ttitle;
	private static JTextField tsearch;
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void MyAlbumWrite() {
		
		
		
		f3.getContentPane().setBackground(Color.GREEN);
		f3.setBackground(Color.GREEN);
		f3.setSize(1600, 860);
		f3.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("나만의 앨범작성");
		lblNewLabel.setBounds(44, 10, 239, 48);
		f3.getContentPane().add(lblNewLabel);

		Panel panel = new Panel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(44, 299, 650, 443);
		f3.getContentPane().add(panel);
		panel.setLayout(null);

		Panel panel_3 = new Panel();
		panel_3.setBackground(Color.PINK);
		panel_3.setBounds(0, 52, 650, 391);
		panel.add(panel_3);
		panel_3.setLayout(null);

		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(633, 0, 17, 391);
		panel_3.add(scrollBar);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(12, 10, 609, 70);
		panel_3.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("50x50");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(12, 10, 50, 50);
		panel_4.add(lblNewLabel_3);
		
		JLabel lblNewLabel_5 = new JLabel("제목");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(74, 10, 319, 50);
		panel_4.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("가수");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(405, 10, 126, 50);
		panel_4.add(lblNewLabel_6);
		
		JButton btnNewButton_6 = new JButton("추가");
		btnNewButton_6.setFont(new Font("굴림", Font.PLAIN, 10));
		btnNewButton_6.setBounds(543, 10, 54, 50);
		panel_4.add(btnNewButton_6);

		JLabel lblNewLabel_4 = new JLabel("검색");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 0, 129, 54);
		panel.add(lblNewLabel_4);

		tsearch = new JTextField();
		tsearch.setColumns(10);
		tsearch.setBounds(129, 0, 418, 53);
		panel.add(tsearch);

		JButton btnNewButton_3 = new JButton("검색");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SongDAO search = new SongDAO();
				String searchtext = tsearch.getText();
				System.out.println(searchtext);
				ArrayList<SongDTO> x = search.MyalbumSearchingsonglist(searchtext);
				System.out.println(x);
				
				
			}
		});
		btnNewButton_3.setBounds(546, 0, 104, 54);
		panel.add(btnNewButton_3);

		Panel panel_2 = new Panel();
		panel_2.setBackground(Color.ORANGE);
		panel_2.setBounds(44, 101, 1460, 170);
		f3.getContentPane().add(panel_2);
		panel_2.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("앨범 제목");
		lblNewLabel_2.setBounds(193, 10, 101, 36);
		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("앨범 장르");
		lblNewLabel_2_1.setBounds(193, 67, 101, 36);
		panel_2.add(lblNewLabel_2_1);

		JLabel lblNewLabel_2_2 = new JLabel("앨범 이미지선택");
		lblNewLabel_2_2.setBounds(193, 124, 101, 36);
		panel_2.add(lblNewLabel_2_2);
		
		
		JLabel showimg = new JLabel("");
		
		
		JButton btnNewButton = new JButton("이미지 불러오기");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				file call = new file();
				String filename = call.jFileChooserUtil();
				ImageIcon icon = new ImageIcon(filename);
		        Image img = icon.getImage(); // ImageIcon을 Image로 변환.
		        Image img2 = img.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH);
		        ImageIcon icon2 = new ImageIcon(img2); // Image로 ImageIcon 생성
		        showimg.setIcon(icon2);
		        showimg.setText(filename);
		        
				
			}
		});
		btnNewButton.setBounds(327, 124, 204, 36);
		panel_2.add(btnNewButton);

		ttitle = new JTextField();
		ttitle.setBounds(327, 10, 406, 36);
		panel_2.add(ttitle);
		ttitle.setColumns(10);

		showimg.setHorizontalAlignment(SwingConstants.CENTER);
		showimg.setBounds(12, 10, 150, 150);
		panel_2.add(showimg);
		
		JCheckBox cb1 = new JCheckBox("힙합");
		
		cb1.setBounds(327, 67, 77, 36);
		panel_2.add(cb1);
		
		JCheckBox cb2 = new JCheckBox("발라드");
		cb2.setBounds(408, 67, 77, 36);
		panel_2.add(cb2);
		
		JCheckBox cb3 = new JCheckBox("pop");
		cb3.setBounds(489, 67, 77, 36);
		panel_2.add(cb3);
		
		JCheckBox cb4 = new JCheckBox("OST");
		cb4.setBounds(570, 67, 77, 36);
		panel_2.add(cb4);
		
		JCheckBox cb5 = new JCheckBox("댄스");
		cb5.setBounds(651, 67, 77, 36);
		panel_2.add(cb5);
		
		JCheckBox cb6 = new JCheckBox("락");
		cb6.setBounds(732, 67, 77, 36);
		panel_2.add(cb6);

		JLabel lblNewLabel_1 = new JLabel("나만의 앨범 정보입력");
		lblNewLabel_1.setBounds(44, 68, 125, 29);
		f3.getContentPane().add(lblNewLabel_1);

		
		
		
		
		JButton btnNewButton_2 = new JButton("앨범올리기");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String text ="";
				String [] x = {"힙합","발라드","pop","OST","댄스", "락"};
				boolean [] y = {cb1.isSelected(),cb2.isSelected(),cb3.isSelected(),cb4.isSelected(),cb5.isSelected(),cb6.isSelected()};
				for (int i = 0; i < x.length; i++) {
					if (y[i]== true) {
						text = x[i]+" "+text;
					} else {
						text = text+"";
					}
				}

				SimpleDateFormat format1 = new SimpleDateFormat();
				Date date = new Date();
				
				String title = ttitle.getText();
//				String nickname = ??    닉네임 불러와야댐
				String now =  format1.format(date);
//				like 는 0으로 초기화 저장
				String tag = text;
//				songcount 는 곡 고른수 변수로 지정.
				String albumcover = showimg.getText();
				System.out.println(now);
				MyAlbumBbsDTO MABDTO = new MyAlbumBbsDTO();
				MABDTO.setBbsid(0);
				MABDTO.setTitle(title);
				MABDTO.setTime(now);
				MABDTO.setTag(tag);
				MABDTO.setAlbumcover(albumcover);
				
				MyAlbumBbsDAO MABDAO = new MyAlbumBbsDAO();
				MABDAO.insert(MABDTO);
				
				JOptionPane.showMessageDialog(null, "나의 앨범 작성이 완료되었습니다.");
				f3.setVisible(false);
				AlbumInner inner = new AlbumInner();
				inner.AlbumInner();
			}
		});
		btnNewButton_2.setBounds(475, 763, 219, 48);
		f3.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_2_1 = new JButton("취소");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyAlubm myalbum = new MyAlubm();
				myalbum.MyAlbum();
				f3.setVisible(false);
			}
		});
		btnNewButton_2_1.setBounds(872, 763, 219, 48);
		f3.getContentPane().add(btnNewButton_2_1);

		Panel panel_1 = new Panel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(872, 299, 650, 443);
		f3.getContentPane().add(panel_1);

		Panel panel_3_1 = new Panel();
		panel_3_1.setBackground(Color.PINK);
		panel_3_1.setLayout(null);
		panel_3_1.setBounds(0, 52, 650, 391);
		panel_1.add(panel_3_1);

		JScrollBar scrollBar_1 = new JScrollBar();
		scrollBar_1.setBounds(633, 0, 17, 391);
		panel_3_1.add(scrollBar_1);

		JLabel lblNewLabel_4_1 = new JLabel("선곡리스트");
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setBounds(0, 0, 650, 54);
		panel_1.add(lblNewLabel_4_1);

		f3.setVisible(true);

	}
}
