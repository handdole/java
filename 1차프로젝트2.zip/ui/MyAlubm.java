package ui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MyAlubm {

	/**
	 * @wbp.parser.entryPoint
	 */
	public void MyAlbum() {
		JFrame f2 = new JFrame();
		f2.getContentPane().setBackground(Color.GREEN);
		f2.getContentPane().setForeground(Color.WHITE);
		f2.setSize(1600, 860);
		f2.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("나만의 앨범");
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 50));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(528, 25, 473, 63);
		f2.getContentPane().add(lblNewLabel);

		Panel panel = new Panel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(94, 113, 356, 531);
		f2.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("게시물번호");
		lblNewLabel_1.setBounds(27, 10, 74, 30);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_3 = new JLabel("TITLE");
		lblNewLabel_3.setBounds(27, 368, 102, 23);
		panel.add(lblNewLabel_3);

		JLabel lblNewLabel_3_1 = new JLabel("NICKNAME");
		lblNewLabel_3_1.setBounds(27, 401, 102, 23);
		panel.add(lblNewLabel_3_1);

		JLabel lblNewLabel_3_2 = new JLabel("TAG/TAG/TAG/TAG");
		lblNewLabel_3_2.setBounds(27, 449, 245, 23);
		panel.add(lblNewLabel_3_2);

		JLabel lblNewLabel_3_3 = new JLabel("수록곡 수");
		lblNewLabel_3_3.setBounds(27, 487, 119, 23);
		panel.add(lblNewLabel_3_3);

		JLabel lblNewLabel_3_4 = new JLabel("LIKE");
		lblNewLabel_3_4.setBounds(242, 491, 102, 23);
		panel.add(lblNewLabel_3_4);

		JLabel lblNewLabel_2 = new JLabel("앨범커버");
		lblNewLabel_2.setBounds(27, 50, 295, 295);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\조은이\\Desktop\\albumcover\\Birthday.png"));
		lblNewLabel_2.setBackground(Color.WHITE);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);

		Panel panel_1 = new Panel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(606, 113, 356, 531);
		f2.getContentPane().add(panel_1);

		JLabel lblNewLabel_1_1 = new JLabel("게시물번호");
		lblNewLabel_1_1.setBounds(27, 10, 74, 30);
		panel_1.add(lblNewLabel_1_1);

		JLabel lblNewLabel_3_5 = new JLabel("TITLE");
		lblNewLabel_3_5.setBounds(27, 368, 102, 23);
		panel_1.add(lblNewLabel_3_5);

		JLabel lblNewLabel_3_1_1 = new JLabel("NICKNAME");
		lblNewLabel_3_1_1.setBounds(27, 401, 102, 23);
		panel_1.add(lblNewLabel_3_1_1);

		JLabel lblNewLabel_3_2_1 = new JLabel("TAG/TAG/TAG/TAG");
		lblNewLabel_3_2_1.setBounds(27, 449, 245, 23);
		panel_1.add(lblNewLabel_3_2_1);

		JLabel lblNewLabel_3_3_1 = new JLabel("수록곡 수");
		lblNewLabel_3_3_1.setBounds(27, 487, 119, 23);
		panel_1.add(lblNewLabel_3_3_1);

		JLabel lblNewLabel_3_4_1 = new JLabel("LIKE");
		lblNewLabel_3_4_1.setBounds(242, 491, 102, 23);
		panel_1.add(lblNewLabel_3_4_1);

		JLabel lblNewLabel_2_1 = new JLabel("앨범커버");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setBackground(Color.WHITE);
		lblNewLabel_2_1.setBounds(27, 50, 295, 295);
		panel_1.add(lblNewLabel_2_1);

		Panel panel_2 = new Panel();
		panel_2.setLayout(null);
		panel_2.setBackground(Color.WHITE);
		panel_2.setBounds(1128, 113, 356, 531);
		f2.getContentPane().add(panel_2);

		JLabel lblNewLabel_1_2 = new JLabel("게시물번호");
		lblNewLabel_1_2.setBounds(27, 10, 74, 30);
		panel_2.add(lblNewLabel_1_2);

		JLabel lblNewLabel_3_6 = new JLabel("TITLE");
		lblNewLabel_3_6.setBounds(27, 368, 102, 23);
		panel_2.add(lblNewLabel_3_6);

		JLabel lblNewLabel_3_1_2 = new JLabel("NICKNAME");
		lblNewLabel_3_1_2.setBounds(27, 401, 102, 23);
		panel_2.add(lblNewLabel_3_1_2);

		JLabel lblNewLabel_3_2_2 = new JLabel("TAG/TAG/TAG/TAG");
		lblNewLabel_3_2_2.setBounds(27, 449, 245, 23);
		panel_2.add(lblNewLabel_3_2_2);

		JLabel lblNewLabel_3_3_2 = new JLabel("수록곡 수");
		lblNewLabel_3_3_2.setBounds(27, 487, 119, 23);
		panel_2.add(lblNewLabel_3_3_2);

		JLabel lblNewLabel_3_4_2 = new JLabel("LIKE");
		lblNewLabel_3_4_2.setBounds(242, 491, 102, 23);
		panel_2.add(lblNewLabel_3_4_2);

		JLabel lblNewLabel_2_2 = new JLabel("앨범커버");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2.setBackground(Color.WHITE);
		lblNewLabel_2_2.setBounds(27, 50, 295, 295);
		panel_2.add(lblNewLabel_2_2);

		JButton btnNewButton = new JButton("이전");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 좋아요 수 기반으로 메인 화면은 1,2,3 등 select 해오기 
				// 이전으로 가면 7,8,9 등 표시 
				// 
				
			}
		});
		btnNewButton.setBounds(538, 683, 195, 54);
		f2.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("다음");
		btnNewButton_1.setBounds(834, 683, 195, 54);
		f2.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("목록보기");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyAlbumList list = new MyAlbumList();
				list.MyAlbumList();
				f2.setVisible(false);
				
			}
		});
		btnNewButton_2.setBounds(675, 767, 217, 44);
		f2.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("나만의 앨범 만들기");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyAlubmWrite write = new MyAlubmWrite();
				write.MyAlbumWrite();
				f2.setVisible(false);

			}
		});
		btnNewButton_3.setBounds(1341, 767, 195, 38);
		f2.getContentPane().add(btnNewButton_3);

		f2.setVisible(true);

	}
}
