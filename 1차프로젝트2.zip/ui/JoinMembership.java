package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DB.sign_upDAO;
import DB.sign_upDTO;

public class JoinMembership {

	JFrame f1 = new JFrame();
	private static JTextField tID;

	private static JTextField tNAME;
	private static JTextField tTEL;
	private static JTextField tEMAIL;
	private static JTextField tNICKNAME;
	private static JPasswordField pw;
	private static JPasswordField pwre;
	private static int flagid;
	private static int flagpw;
	
	
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public void joinmembershipUI() {
		f1.getContentPane().setBackground(Color.GREEN);
		f1.setTitle("회원가입 화면");
		f1.setSize(1600, 860);
		f1.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("회원가입");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 50));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(429, 10, 729, 95);
		f1.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("아이디");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(181, 123, 226, 57);
		f1.getContentPane().add(lblNewLabel_1);

		tID = new JTextField();
		tID.setBounds(604, 123, 737, 57);
		f1.getContentPane().add(tID);
		tID.setColumns(10);

		JLabel lblNewLabel_1_1 = new JLabel("비밀번호");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(181, 202, 226, 57);
		f1.getContentPane().add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("비밀번호확인");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_2.setBounds(181, 282, 226, 57);
		f1.getContentPane().add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_3 = new JLabel("이름");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setForeground(Color.WHITE);
		lblNewLabel_1_3.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_3.setBounds(181, 368, 226, 57);
		f1.getContentPane().add(lblNewLabel_1_3);

		tNAME = new JTextField();
		tNAME.setColumns(10);
		tNAME.setBounds(604, 368, 737, 57);
		f1.getContentPane().add(tNAME);

		JLabel lblNewLabel_1_4 = new JLabel("번호");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setForeground(Color.WHITE);
		lblNewLabel_1_4.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_4.setBounds(181, 464, 226, 57);
		f1.getContentPane().add(lblNewLabel_1_4);

		tTEL = new JTextField();
		tTEL.setColumns(10);
		tTEL.setBounds(604, 464, 737, 57);
		f1.getContentPane().add(tTEL);

		JLabel lblNewLabel_1_5 = new JLabel("이메일");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setForeground(Color.WHITE);
		lblNewLabel_1_5.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_5.setBounds(181, 560, 226, 57);
		f1.getContentPane().add(lblNewLabel_1_5);

		tEMAIL = new JTextField();
		tEMAIL.setColumns(10);
		tEMAIL.setBounds(604, 566, 737, 57);
		f1.getContentPane().add(tEMAIL);

		JLabel lblNewLabel_1_6 = new JLabel("닉네임");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setForeground(Color.WHITE);
		lblNewLabel_1_6.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_6.setBounds(181, 649, 226, 57);
		f1.getContentPane().add(lblNewLabel_1_6);

		pw = new JPasswordField();
		pwre = new JPasswordField();

		tNICKNAME = new JTextField();
		tNICKNAME.setColumns(10);
		tNICKNAME.setBounds(604, 649, 737, 57);
		f1.getContentPane().add(tNICKNAME);

		JButton btnNewButton = new JButton("가입완료");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String pw2 = "";
				char[] secret_pw = pw.getPassword();
				pw2 = String.valueOf(secret_pw);
				
				// 1. 아이디 중복확인했니? if ( flag id != 0) 아이디 중복확인바람
				// 2. 비밀번호 확인 했니? else if ( flag pw != 0) 비밀번호 중복확인바람
				// 3. 모든 칸에 값이 들어갔니? else 밑에 if else 절 들어감.
				
				
				if (tID.getText().equals("") || 
						pw2 == "" ||
						tNAME.getText().equals("") ||
						tTEL.getText().equals("") ||
						tEMAIL.getText().equals("") ||
						tNICKNAME.getText().equals("") ) {	
					JOptionPane.showMessageDialog(null, "모든 정보를 입력해주세요.");
					
				} else {
					
					String id = tID.getText();
					String name = tNAME.getText();
					String tel = tTEL.getText();
					String email = tEMAIL.getText();
					String nickname = tNICKNAME.getText();
					
					sign_upDTO signup = new sign_upDTO();
					signup.setId(id);
					signup.setPw(pw2);
					signup.setName(name);
					signup.setTel(tel);
					signup.seteMail(email);
					signup.setNickname(nickname);
					
					sign_upDAO signupdao = new sign_upDAO();
					signupdao.insert(signup);
					
					JOptionPane.showMessageDialog(null, "회원가입이 완료되었습니다.");
					f1.setVisible(false);
					login start = new login();
					start.loginUI();
				}
				
			}
		});
		btnNewButton.setBounds(429, 745, 277, 49);
		f1.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("취소");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login log = new login();
				log.loginUI();
				f1.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(968, 745, 277, 49);
		f1.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("비밀번호 확인");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				@SuppressWarnings("deprecation")
//				String PW = pw.getText();
				String PW = "";
				char[] secret_pw = pw.getPassword();
				PW = String.valueOf(secret_pw);
//				@SuppressWarnings("deprecation")
//				String PWRE = pwre.getText();
				String PWRE = "";
				char[] secret_pw2 = pwre.getPassword();
				PWRE = String.valueOf(secret_pw2);
				if (PW.equals("") || PWRE.equals("")) {
					JOptionPane.showMessageDialog(null, "비밀번호를 입력해주세요.");
				} else {
					if (PW.equals(PWRE)) {
						JOptionPane.showMessageDialog(null, "비밀번호가 확인되었습니다.");
						btnNewButton_2.setEnabled(false);
						flagpw = 1;
					} else {
						JOptionPane.showMessageDialog(null, "비밀번호가 일치하지 않습니다.");
					}
				}

			}
		});
		btnNewButton_2.setBounds(1377, 282, 125, 57);
		f1.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("아이디 중복확인");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {    //select 사용해서 DB에 있는 id 와  회원가입하려는 사람의 아이디 같은지 다른지 확인.
				
			}
		});
		btnNewButton_3.setBounds(1377, 123, 125, 57);
		f1.getContentPane().add(btnNewButton_3);

		pw.setEchoChar('*');
		pw.setBounds(604, 202, 737, 57);
		f1.getContentPane().add(pw);

		pwre.setEchoChar('*');
		pwre.setBounds(604, 282, 737, 57);
		f1.getContentPane().add(pwre);

		f1.setVisible(true);
	}

}
