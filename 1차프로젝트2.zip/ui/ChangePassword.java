package ui;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ChangePassword {
	private JPasswordField now;
	private JPasswordField newpass;
	private JPasswordField newpassRE;

	private static String password;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void Changepassword() {

		JFrame f = new JFrame();
		f.getContentPane().setBackground(Color.GREEN);
		f.setSize(500, 500);
		f.getContentPane().setLayout(null);

		now = new JPasswordField();
		newpass = new JPasswordField();
		newpassRE = new JPasswordField();

		JLabel lblNewLabel = new JLabel("비밀번호 변경");
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(111, 33, 276, 58);
		f.getContentPane().add(lblNewLabel);

		JButton btnNewButton = new JButton("확인");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (now.equals(password)) { // 현재 비밀번호 란에 들어간 now 가 사용자의 비밀번호와 일치한다면.
					if (newpass.equals(newpassRE)) { // 새 비밀번호와 새비밀번호 확인이 일치한다면
						JOptionPane.showMessageDialog(null, "비밀번호가 변경되었습니다.");
					} else { // 새 비밀번호와 새비밀번호 확인이 일치하지 않는다면
						JOptionPane.showMessageDialog(null, "새 비밀번호가 일치하지 않습니다.");
					}

				} else { // 일치하지 않는다면.
					JOptionPane.showMessageDialog(null, "현재 비밀번호가 일치하지 않습니다.");

				}
			}
		});
		btnNewButton.setBounds(47, 356, 140, 50);
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("취소");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(295, 356, 140, 50);
		f.getContentPane().add(btnNewButton_1);

		JLabel lblNewLabel_1 = new JLabel("현재비밀번호");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(27, 147, 88, 32);
		f.getContentPane().add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("새 비밀번호");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(27, 229, 88, 32);
		f.getContentPane().add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("새비밀번호확인");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setBounds(27, 279, 88, 32);
		f.getContentPane().add(lblNewLabel_1_2);

		now.setEchoChar('*');
		now.setBounds(165, 147, 235, 32);
		f.getContentPane().add(now);

		now.setEchoChar('*');
		newpass.setBounds(165, 229, 235, 32);
		f.getContentPane().add(newpass);

		now.setEchoChar('*');
		newpassRE.setBounds(165, 279, 235, 32);
		f.getContentPane().add(newpassRE);

		f.setVisible(true);
	}
}
