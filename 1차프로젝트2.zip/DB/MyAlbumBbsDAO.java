package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class MyAlbumBbsDAO {
	String url = "jdbc:mysql://localhost:3708/project";
	String user = "root";
	String password = "1234";



	public void insert(MyAlbumBbsDTO x) {    
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 커넥터 설정 ok...");
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok...");
			
			
			
			String sql = "insert into my_album_bbs values(?,?,null,?,null,null,null,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1,x.getBbsid());
			ps.setString(2,x.getTitle());
			ps.setString(3,x.getTime());
			ps.setString(4,x.getAlbumcover());
			
			System.out.println("3. sql 문 결정 ok...");
			
			ps.executeLargeUpdate();
			System.out.println("4.sql문 전송 ok...");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	
}
