package DB;

public class MyAlbumBbsDTO {
	public int bbsid;
	public String title;
	public String nickname;
	public String time; 
	public int like;
	public String tag;
	public int songcount;
	public String albumcover;
	
	public int getBbsid() {
		return bbsid;
	}
	public void setBbsid(int bbsid) {
		this.bbsid = bbsid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getLike() {
		return like;
	}
	public void setLike(int like) {
		this.like = like;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public int getSongcount() {
		return songcount;
	}
	public void setSongcount(int songcount) {
		this.songcount = songcount;
	}
	public String getAlbumcover() {
		return albumcover;
	}
	public void setAlbumcover(String albumcover) {
		this.albumcover = albumcover;
	}

	
	
	
	
}
