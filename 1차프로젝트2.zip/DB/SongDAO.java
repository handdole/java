
package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class  SongDAO {
   String url = "jdbc:mysql://localhost:3708/project";
   String user = "root";
   String password = "1234";
   Connection con = null;
   ResultSet rs = null;
   Statement stmt = null;

   public ArrayList<SongDTO> MyalbumSearchingsonglist(String searching) {
      ArrayList<SongDTO> songList = new ArrayList<SongDTO>();
     // 이거는 myalbum에 사용되는 메소드 
      try {
         // 1) 커넥터 설정
         Class.forName("com.mysql.jdbc.Driver");
         System.out.println("1. 커넥터 설정 OK");

         // 2) DB연결
         con = DriverManager.getConnection(url, user, password);
         System.out.println("2. DB연결 OK");

         // 3) sql문 결정
         String sql = "select album_cover , song_title , artist  from song where artist = ? ";
         PreparedStatement ps = con.prepareStatement(sql);
         ps.setString(1, searching);
         
         // 4) sql문 전송
         rs = ps.executeQuery(sql);
         System.out.println("4. SQL문 전송 OK");

         while (rs.next()) {
        	 SongDTO bag = new SongDTO();
        	 bag.setAlbumcover(rs.getString(1));
        	 bag.setSongtitle(rs.getString(2));
        	 bag.setArtist(rs.getString(3));
        	 
        	 songList.add(bag);
        	 
         }

      } catch (Exception e) {
         e.printStackTrace();
      }
      return songList;
   }


}