package ui;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Panel;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DB.ImageResize;
import DB.file;

import javax.swing.JScrollPane;
import java.awt.Scrollbar;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.lang.reflect.Parameter;
import java.awt.event.ActionEvent;

public class MyAlubmWrite {
	
	
	JFrame f3 = new JFrame();
	private static JTextField textField_1;
	private static JTextField textField;
	/**
	 * @wbp.parser.entryPoint
	 */
	public void MyAlbumWrite() {

		f3.getContentPane().setBackground(Color.GREEN);
		f3.setBackground(Color.GREEN);
		f3.setSize(1600, 860);
		f3.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("나만의 앨범작성");
		lblNewLabel.setBounds(44, 10, 239, 48);
		f3.getContentPane().add(lblNewLabel);

		Panel panel = new Panel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(44, 299, 650, 443);
		f3.getContentPane().add(panel);
		panel.setLayout(null);

		Panel panel_3 = new Panel();
		panel_3.setBackground(Color.PINK);
		panel_3.setBounds(0, 52, 650, 391);
		panel.add(panel_3);
		panel_3.setLayout(null);

		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(633, 0, 17, 391);
		panel_3.add(scrollBar);

		JLabel lblNewLabel_4 = new JLabel("검색");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 0, 129, 54);
		panel.add(lblNewLabel_4);

		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(129, 0, 418, 53);
		panel.add(textField);

		JButton btnNewButton_3 = new JButton("검색");
		btnNewButton_3.setBounds(546, 0, 104, 54);
		panel.add(btnNewButton_3);

		Panel panel_2 = new Panel();
		panel_2.setBackground(Color.ORANGE);
		panel_2.setBounds(44, 101, 1460, 170);
		f3.getContentPane().add(panel_2);
		panel_2.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("앨범 제목");
		lblNewLabel_2.setBounds(193, 10, 101, 36);
		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("앨범 장르");
		lblNewLabel_2_1.setBounds(193, 67, 101, 36);
		panel_2.add(lblNewLabel_2_1);

		JLabel lblNewLabel_2_2 = new JLabel("앨범 이미지선택");
		lblNewLabel_2_2.setBounds(193, 124, 101, 36);
		panel_2.add(lblNewLabel_2_2);
		
		
		JLabel showimg = new JLabel("앨범 이미지");

		
		JButton btnNewButton = new JButton("이미지 불러오기");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				file call = new file();
				String filename = call.jFileChooserUtil();
				ImageResize resize = new ImageResize();
				resize.Resize(filename);
				ImageIcon icon = new ImageIcon(filename+".resize.png");
				showimg.setIcon(icon);
				
				
				
			}
		});
		btnNewButton.setBounds(327, 124, 204, 36);
		panel_2.add(btnNewButton);

		textField_1 = new JTextField();
		textField_1.setBounds(327, 10, 406, 36);
		panel_2.add(textField_1);
		textField_1.setColumns(10);

		showimg.setHorizontalAlignment(SwingConstants.CENTER);
		showimg.setBounds(12, 10, 150, 150);
		panel_2.add(showimg);

		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.setBounds(327, 67, 73, 36);
		panel_2.add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("New button");
		btnNewButton_1_1.setBounds(412, 67, 73, 36);
		panel_2.add(btnNewButton_1_1);

		JButton btnNewButton_1_2 = new JButton("New button");
		btnNewButton_1_2.setBounds(497, 67, 73, 36);
		panel_2.add(btnNewButton_1_2);

		JButton btnNewButton_1_3 = new JButton("New button");
		btnNewButton_1_3.setBounds(582, 67, 73, 36);
		panel_2.add(btnNewButton_1_3);

		JButton btnNewButton_1_4 = new JButton("New button");
		btnNewButton_1_4.setBounds(667, 67, 73, 36);
		panel_2.add(btnNewButton_1_4);

		JButton btnNewButton_1_5 = new JButton("New button");
		btnNewButton_1_5.setBounds(752, 67, 73, 36);
		panel_2.add(btnNewButton_1_5);

		JButton btnNewButton_1_6 = new JButton("New button");
		btnNewButton_1_6.setBounds(837, 67, 73, 36);
		panel_2.add(btnNewButton_1_6);

		JButton btnNewButton_1_7 = new JButton("New button");
		btnNewButton_1_7.setBounds(922, 67, 73, 36);
		panel_2.add(btnNewButton_1_7);

		JButton btnNewButton_1_8 = new JButton("New button");
		btnNewButton_1_8.setBounds(1007, 67, 73, 36);
		panel_2.add(btnNewButton_1_8);

		JLabel lblNewLabel_1 = new JLabel("나만의 앨범 정보입력");
		lblNewLabel_1.setBounds(44, 68, 125, 29);
		f3.getContentPane().add(lblNewLabel_1);

		JButton btnNewButton_2 = new JButton("앨범올리기");
		btnNewButton_2.setBounds(475, 763, 219, 48);
		f3.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_2_1 = new JButton("취소");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MyAlubm myalbum = new MyAlubm();
				myalbum.MyAlbum();
				f3.setVisible(false);
			}
		});
		btnNewButton_2_1.setBounds(872, 763, 219, 48);
		f3.getContentPane().add(btnNewButton_2_1);

		Panel panel_1 = new Panel();
		panel_1.setLayout(null);
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(872, 299, 650, 443);
		f3.getContentPane().add(panel_1);

		Panel panel_3_1 = new Panel();
		panel_3_1.setBackground(Color.PINK);
		panel_3_1.setLayout(null);
		panel_3_1.setBounds(0, 52, 650, 391);
		panel_1.add(panel_3_1);

		JScrollBar scrollBar_1 = new JScrollBar();
		scrollBar_1.setBounds(633, 0, 17, 391);
		panel_3_1.add(scrollBar_1);

		JLabel lblNewLabel_4_1 = new JLabel("선곡리스트");
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setBounds(0, 0, 650, 54);
		panel_1.add(lblNewLabel_4_1);

		f3.setVisible(true);

	}
}
