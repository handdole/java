package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class MyInfoUpdate {
	JFrame f2 = new JFrame();
	private static JTextField tID;
	private static JTextField tPW;
	private static JTextField tPWRE;
	private static JTextField tNAME;
	private static JTextField tTEL;
	private static JTextField tEMAIL;
	private static JTextField tNICKNAME;

	/**
	 * @wbp.parser.entryPoint
	 */
	public void MyInfoUpdateUI() {
		f2.getContentPane().setBackground(Color.GREEN);
		f2.setTitle("회원가입 화면");
		f2.setSize(1600, 860);
		f2.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("나의 정보");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 50));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(429, 10, 729, 95);
		f2.getContentPane().add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("아이디");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(181, 105, 226, 57);
		f2.getContentPane().add(lblNewLabel_1);

		tID = new JTextField();
		tID.setBounds(604, 105, 737, 57);
		f2.getContentPane().add(tID);
		tID.setColumns(10);

		JLabel lblNewLabel_1_1 = new JLabel("비밀번호");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(181, 184, 226, 57);
		f2.getContentPane().add(lblNewLabel_1_1);

		tPW = new JTextField();
		tPW.setColumns(10);
		tPW.setBounds(604, 184, 737, 57);
		f2.getContentPane().add(tPW);

		JLabel lblNewLabel_1_2 = new JLabel("비밀번호확인");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_2.setBounds(181, 264, 226, 57);
		f2.getContentPane().add(lblNewLabel_1_2);

		tPWRE = new JTextField();
		tPWRE.setColumns(10);
		tPWRE.setBounds(604, 264, 737, 57);
		f2.getContentPane().add(tPWRE);

		JLabel lblNewLabel_1_3 = new JLabel("이름");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setForeground(Color.WHITE);
		lblNewLabel_1_3.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_3.setBounds(181, 350, 226, 57);
		f2.getContentPane().add(lblNewLabel_1_3);

		tNAME = new JTextField();
		tNAME.setColumns(10);
		tNAME.setBounds(604, 350, 737, 57);
		f2.getContentPane().add(tNAME);

		JLabel lblNewLabel_1_4 = new JLabel("번호");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setForeground(Color.WHITE);
		lblNewLabel_1_4.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_4.setBounds(181, 446, 226, 57);
		f2.getContentPane().add(lblNewLabel_1_4);

		tTEL = new JTextField();
		tTEL.setColumns(10);
		tTEL.setBounds(604, 446, 737, 57);
		f2.getContentPane().add(tTEL);

		JLabel lblNewLabel_1_5 = new JLabel("이메일");
		lblNewLabel_1_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_5.setForeground(Color.WHITE);
		lblNewLabel_1_5.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_5.setBounds(181, 542, 226, 57);
		f2.getContentPane().add(lblNewLabel_1_5);

		tEMAIL = new JTextField();
		tEMAIL.setColumns(10);
		tEMAIL.setBounds(604, 542, 737, 57);
		f2.getContentPane().add(tEMAIL);

		JLabel lblNewLabel_1_6 = new JLabel("닉네임");
		lblNewLabel_1_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_6.setForeground(Color.WHITE);
		lblNewLabel_1_6.setFont(new Font("굴림", Font.PLAIN, 30));
		lblNewLabel_1_6.setBounds(181, 631, 226, 57);
		f2.getContentPane().add(lblNewLabel_1_6);

		tNICKNAME = new JTextField();
		tNICKNAME.setColumns(10);
		tNICKNAME.setBounds(604, 631, 737, 57);
		f2.getContentPane().add(tNICKNAME);

		JButton btnNewButton = new JButton("정보 수정");
		btnNewButton.setBounds(429, 727, 277, 49);
		f2.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("회원탈퇴");
		btnNewButton_1.setBounds(968, 727, 277, 49);
		f2.getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("비밀번호 확인");
		btnNewButton_2.setBounds(1377, 264, 125, 57);
		f2.getContentPane().add(btnNewButton_2);

		JButton btnNewButton_3 = new JButton("아이디 중복확인");
		btnNewButton_3.setBounds(1377, 105, 125, 57);
		f2.getContentPane().add(btnNewButton_3);

		f2.setVisible(true);

	}

}
